package com.test.vuln;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;


@SpringBootApplication
@RestController
public class VulnApplication {

	private static final Logger logger = LogManager.getLogger(VulnApplication.class);

	public static void main(String[] args) {
		SpringApplication.run(VulnApplication.class, args);
	}


	@GetMapping("/")
    public String submit(@RequestHeader("User-Agent") String userinput) {
        logger.info(userinput);
        return "Log4shell Successfully Requested";
    }
        
}
