package com.test.vuln;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VulnApplicationTests {

	@Test
	void contextLoads() {
	}

}
